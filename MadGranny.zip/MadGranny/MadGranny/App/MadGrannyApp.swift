//
//  MadGrannyApp.swift
//  MadGranny
//
//  Created by Yuliia on 07/12/23.
//

import SwiftUI

@main
struct MadGrannyApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
